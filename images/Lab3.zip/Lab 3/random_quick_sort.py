import random

def quick_sort(a, left, right):
	if left < right:
		pivot = random_partition(a, left, right)
		quick_sort(a, left, pivot-1)
		quick_sort(a, pivot+1, right)
		
		
def random_partition(a, left, right):
	ran=random.randint(left,right)
	a[ran],a[left]=a[left],a[ran]
	return partition(a, left, right)

def partition(a, start, end):
	pivot = a[start]
	left = start+1
	right = end
	done = False
	while right >= left:
		while left <= right and a[left] <= pivot:
			left = left + 1
		while a[right] >= pivot and right >=left:
			right = right -1
		if right>=left:
			a[left],a[right]=a[right],a[left]
	a[start],a[right]=a[right],a[start]
	return right
    
a=[345,23,0,7,243,12,13,33,687,231,1346,24,122,4,65,234,23424,244,44,42]
quick_sort(a,0,len(a)-1)
print "Quick sort array:" ,a
