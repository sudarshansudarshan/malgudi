import numpy
import random

total_iteration=1000
mat=numpy.zeros((100, 100))

def quick_sort(a, left, right):
	if left < right:
		pivot = partition(a, left, right)
		quick_sort(a, left, pivot-1)
		quick_sort(a, pivot+1, right)
    
def partition(a, start, end):
	pivot = a[start]
	left = start+1
	right = end
	done = False
	while right >= left:
		if left <= right:
			mat[start][left]+=1
			mat[left][start]+=1
			while left <= right and a[left] <= pivot:
				left = left + 1
				if left <=right:
					mat[start][left]+=1
					mat[left][start]+=1
		if right >=left:
			mat[start][right]+=1
			mat[right][start]+=1
			while a[right] >= pivot and right >=left:
				right = right -1
				if right >=left:
					mat[start][right]+=1
					mat[right][start]+=1
		if right>=left:
			a[left],a[right]=a[right],a[left]
	a[start],a[right]=a[right],a[start]
	return right
    
a=random.sample(range(1000), 100)
for i in range(total_iteration):
	random.shuffle(a)
	quick_sort(a,0,len(a)-1)

mat=mat/1000
print "average matrix over 1000 iteration : ",mat 

