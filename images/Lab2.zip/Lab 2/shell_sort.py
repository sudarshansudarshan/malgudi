def sort(a):
	""" this function takes a list as input and sort it using Shell Sort Algorithm
	"""
	gap=len(a)/2
	while(gap>0):
		for p in range(gap,len(a)):
			tmp=a[p]
			j=p
			while(j>=gap and tmp<a[j-gap]):
				a[j]=a[j-gap]
				j=j-gap
			a[j]=tmp 
		#print a
		gap=gap/2
	

a=[45,34,657,44,21,5657,3434,1,3,221,465]	
""" Call to Shell Sort Algo"""
sort(a)
print a


