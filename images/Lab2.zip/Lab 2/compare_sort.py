import math
import random
import timeit
import time

ins_sort_time=[]
mod_ins_sort_time=[]
list_size = [10, 60, 110, 160, 210, 260, 310, 360, 410, 460, 510, 560, 610, 660, 710, 760, 810, 860, 910, 960]
avg_alpha = [146, 9109, 36561, 77008, 146897, 229686, 324903, 465190, 614349, 783234, 1029544, 1145292, 1395522, 1668786, 2051283, 2256005, 2603682, 2931674, 3312584, 3949407]


def random_swap(a,k):
	"""Perform K no of random swap on the given list a. """
	l=len(a)
	for r in range(k):
		i=random.randint(0,l-1)
		j=random.randint(0,l-1)
		#print "i,j ",i,j
		if i>j:
			i,j=j,i
		if(a[i]>a[j]):
			a[i],a[j]=a[j],a[i]
			#print "swap", i,j


def ins_sort(a):
	"""Perform Insertion Sort on the given list a. """
	no_of_swap=0
	l=len(a)
	for i in range(1,l):
		key=a[i]
		j=i-1
		while(key<a[j] and j>=0):
			no_of_swap+=1
			a[j+1]=a[j]
			j=j-1
		a[j+1]=key
	return no_of_swap

def compare(a,k):
	"""Return no of swap taken by insertion sort and no of swap taken by insertion sort after k (avg calculated value of alpha i.e. random no of swap after which list is sorted) Random swap on the given list a """
	tmp=[]
	tmp.extend(a) 
	time1=ins_sort(tmp)
	random_swap(a,k)
	time2=ins_sort(a)
	ins_sort_time.append(time1)
	mod_ins_sort_time.append(time2)
	return [time1,time2]

print "Program Execution Started"	
for i in range(len(list_size)): 
	"""Compare no of swap on the given list with given avg value of alpha. """
	a=random.sample(range(10000), list_size[i]) # Generate Random list of Given list size
	t=compare(a,avg_alpha[i]) # Call Compare Function with Generated List and Corresponding calculated value of alpha.

print list_size
print ins_sort_time
print mod_ins_sort_time


