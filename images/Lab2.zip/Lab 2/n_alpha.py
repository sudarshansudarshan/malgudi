import math
import random
import timeit
import pdb
from matplotlib import pyplot
from numpy import arange

avg_alpha=[]
list_size=[]
avg_swap=[]
tmp=[]
a=[]
tmp11=[]
list_size=range(10,1000,50)

def scatterplot(x,y):
	"""To plot the Graph K (list size) versus alpha (avg calculated value of Random Swap) """
    	pyplot.plot(x,y,'b.')
    	pyplot.xlim(min(x)-1,max(x)+1)
    	pyplot.ylim(min(y)-1,max(y)+1)
    	pyplot.show()


def random_swap(a):
	"""Choose two random indexes and if these two values(corresponding to indexes) are not in sorted order perform swap in the given list a. """
	l=len(a)
	i=random.randint(0,l-1)
	j=random.randint(0,l-1)
	if i>j:
		i,j=j,i
	if(a[i]>a[j]):
		a[i],a[j]=a[j],a[i]
		return 1
	return 0


def is_sort(a):
	""" For the given list a, it checks that list is sorted or not."""
	for i in range(len(a)-1):
		if a[i+1]<a[i]:
			return False
	return True
	
def calc_avg_alpha(a):
	"""Calculate average value of random swap after which list will be sorted, here we are calculating avg of 40 iteration. """
	#print " calc_avg_alpha for list length : ", len(a)
	tmp_no_swap=[]
	tmp_act_no_swap=[]
	for i in range(40):
		tmp=[]
		tmp.extend(a)
		tmp11=calc_alpha(tmp)
		#print tmp11
		tmp_no_swap.append(tmp11[0])
		tmp_act_no_swap.append(tmp11[1])
	return [sum(tmp_no_swap) / float(len(tmp_no_swap)),sum(tmp_act_no_swap) / float(len(tmp_act_no_swap))]

def calc_alpha(a):
	"""Calculate no of random swap for sorting a given list. """
	no_of_swap=0
	no_of_act_swap=0
	while True:
		no_of_act_swap+=random_swap(a)
		if(is_sort(a)):
			break
		no_of_swap+=1
	return [no_of_swap,no_of_act_swap]


#pdb.set_trace()
print "Program Execution Started"
target = open("result_final.txt", 'w')

for i in list_size:
	a=random.sample(range(10000), i)
	tmp11=calc_avg_alpha(a)
	avg_alpha.append(tmp11[0])
	avg_swap.append(tmp11[1])
	target.write("list_size :: " )
	target.write("%d" %i)
	target.write("alpha value array\n")
	target.writelines(["%s\n" % item  for item in tmp11])

print "list_size", len(list_size),list_size
print "avg_alpha", len(avg_alpha),avg_alpha
print "avg_swap", len(avg_alpha),avg_swap
target.close()
scatterplot(list_size,avg_alpha)


