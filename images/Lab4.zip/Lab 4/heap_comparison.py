import math
import random
import time

def left_child(i):
	"""Return the index of left Child in Binary Heap"""
	return 2*i+1

def right_child(i):
	"""Return the index of right Child in Binary Heap"""
	return 2*i+2

def heapify(a,i,len):
	"""This Function takes Input as an array (a), Index(i) that needs to be heapify and len of the array a (len) in the given array,...
	that we need to consider during heapify function """
	l = left_child(i)
	r = right_child(i)
	max_index=i
	if r<len and a[r]>a[i]:
		max_index=r
	if l<len and a[l]>a[max_index]:
		max_index=l
	if max_index!=i:
		a[i],a[max_index] = a[max_index],a[i]
		heapify(a,max_index,len)

# build a heap A from an unsorted array          
def Build_heap(a):
	"""This Function takes an unsorted array as Input and Convert it into a Max Heap."""
	l = len(a)
	for i in range(l//2-1,-1,-1):
		heapify(a,i,l)
	#print "heapified array is : " ,a

def heap(a):
	"""This Function Perform Binary Heap Sort Algorithm on the given array 'a'."""
	l = len(a)
	Build_heap(a)
	for i in range(l-1,0,-1):
		a[0],a[i] = a[i],a[0]
		l=l-1
		heapify(a,0,l)

"""Ternary Heap Sort Functions are defined. """

def ternary_heapify(b,i,len):
	"""This Function takes Input as an array (a), Index(i) that needs to be heapify and len of the array a (len) in the given array,...
	that we need to consider during heapify function """
	max_index=i
	if (3*i+1)<len and a[3*i+1]>b[i]:
		max_index=3*i+1
	if 3*i+2<len and a[3*i+2]>b[max_index]:
		max_index=3*i+2
	if 3*i+3<len and a[3*i+3]>b[max_index]:
		max_index=3*i+3
	if max_index!=i:
		b[i],b[max_index] = b[max_index],b[i]
		ternary_heapify(b,max_index,len)

# build a heap A from an unsorted array          
def ternary_Build_heap(b):
	"""This Function takes an unsorted array as Input and Convert it into a Max Heap."""
	l = len(b)
	for i in range((l-2)//3,-1,-1): 
		ternary_heapify(b,i,l)
	#print "heapified array is : " ,b

def ternary_heap(b):
	"""This Function Perform Ternary Heap Sort Algorithm on the given array 'a'."""
	l = len(b)
	ternary_Build_heap(b)
	for i in range(l-1,0,-1):
		b[0],b[i] = b[i],b[0]
		l=l-1
		ternary_heapify(b,0,l)

a=random.sample(range(10000000), 1000000)
b=[]
b.extend(a)
t1=time.time()
heap(a)
diff1=time.time()-t1
t1=time.time()
ternary_heap(b)
diff2=time.time()-t1
if diff1>diff2:
	print "Ternary Heap Sort Is Faster by : ",diff1-diff2
else:
	print "Ternary Heap Sort Is Faster by : ",diff2-diff1
#print "heap sort array:" ,a
  
