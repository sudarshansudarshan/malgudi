import random
import numpy

"""This program prints A odd Dimension Matrix spirally starting from the centre. """
n=11 ## dimension of matrix, u can assign any odd no to this

def spiral(a):
	x,y=(n-1)/2,(n-1)/2
	if 0<=x<n and 0<=y<n:
		print a[x,y]  ## print middle element
	for i in range(1,n+1):
		if(i%2==1):
			for k in range(i): ## print down element
				x=x+1
				if 0<=x<n and 0<=y<n:
					print a[x,y]
			for k in range(i): ## print right element
				y=y+1
				if 0<=x<n and 0<=y<n:
					print a[x,y]
		else:
			for k in range(i): ## print up element
				x=x-1
				if 0<=x<n and 0<=y<n:
					print a[x,y]
			for k in range(i): ## print left element
				y=y-1
				if 0<=x<n and 0<=y<n:
					print a[x,y]
		
a=numpy.random.randint(100, size=(n,n)) ## Generate random matrix of given size
print "Matrix :", a
spiral(a)
#print "a1", a
