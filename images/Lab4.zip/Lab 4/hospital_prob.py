import numpy
import random
import time
import string
import math

"""This File is used to serve Maximum 20 Patient """

patient_queue=[]
max_patient=20

def generate_name(size=4, chars=string.ascii_uppercase ):
	"""Generate a random String and return it"""
	return ''.join(random.choice(chars) for i in range(size))
	
def generate_crit():
	"""Generate a random no and return it as criticality """
	return random.randint(1,40)		

def move_down(a,i,len):
	"""This Function takes Input as a queue (a), Index(i) that needs to be heapify and len of the queue (len),
	that we need to consider during heapify function and we move down element to maintain max heap property. """
	l = 2*i+1
	r = 2*i+2
	max_index=i
	if r<len and a[r][1]>a[i][1]:
		max_index=r
	if l<len and a[l][1]>a[max_index][1]:
		max_index=l
	if max_index!=i:
		a[i][0],a[i][1],a[max_index][0],a[max_index][1] = a[max_index][0],a[max_index][1],a[i][0],a[i][1]
		move_down(a,max_index,len)

def move_up(a,i):
	"""This Function takes Input as Queue (a), Index(i) and move the element up to maintain max heap. """
	p=int(math.floor((i-1)/2))
	index=i
	if p>=0 and a[p][1]<a[i][1]:
		index=p
	if index!=i:
		a[i][0],a[i][1],a[index][0],a[index][1] = a[index][0],a[index][1],a[i][0],a[i][1]
		move_up(a,index)
	
def service(patient_queue,p,crit):
	"""This Function is used to serve a given patient """
	time.sleep(0.00001*random.random())
	
def Extract_most_critical(patient_queue):
	"""This Patient is used to extract most critical Patient from the queue. """
	if (len(patient_queue)==0):
		print "No patient is Present to Service."
	else:
		pat_name= patient_queue[0][0]
		pat_crit=patient_queue[0][1]
		patient_queue[0][0],patient_queue[0][1]=patient_queue[len(patient_queue)-1][0],patient_queue[len(patient_queue)-1][1]
		patient_queue.pop()
		move_down(patient_queue,0,len(patient_queue))
		print "Patient went for Service is : ",pat_name
		return [pat_name,pat_crit]
	
	
def increase_crit(patient_queue,name,crit1):
	"""This function update the criticality of the given patient with given criticality"""
	for i in range(0,len(patient_queue)):
		if(patient_queue[i][0]==name):
			patient_queue[i][1]=crit1
			move_up(patient_queue,i)
			break
	print "patient Criticality is increased for patient ", name
	
def add(patient_queue,name,crit):
	"""This Function add the new patient in the queue and also call move_up function to maintain max heap."""
	patient_queue.append([name,crit])
	move_up(patient_queue,len(patient_queue)-1)
	print "Current patient Queue : ",patient_queue
	
def simulation(patient_queue,max_patient):
	"""This function is used to call randomly all function and serve maximum no of patient. """
	no_of_patient=0
	max_no_of_patient=max_patient
	served_patient=0
	while True:
		i=random.randint(1,30)
		if i%2==0:
			if no_of_patient == max_no_of_patient:
				continue
			else:
				add(patient_queue,generate_name(),generate_crit())
				no_of_patient+=1
		elif i%3==0:
			if len(patient_queue)>0:
				pat_no=random.randint(0,len(patient_queue)-1)
				#print "len(patient_queue) ",len(patient_queue)
				#print "pat_no ",pat_no
				increase_crit(patient_queue,patient_queue[pat_no][0],int(patient_queue[pat_no][1])+random.randint(1,4))
		else:
			if served_patient < max_no_of_patient and len(patient_queue)>0:
				served_patient+=1
				#print "served_patient ",served_patient
				t=Extract_most_critical(patient_queue)
				service(patient_queue,t[0],t[1])
			if served_patient==max_no_of_patient:
				return
					
simulation(patient_queue, max_patient)
print " All Patients are served."
