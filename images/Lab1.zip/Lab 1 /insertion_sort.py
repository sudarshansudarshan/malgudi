def ins_sort(a):
	"""Perform insertion sort algorithm on the given list a. """
	l=len(a)
	for i in range(1,l):
		key=a[i]
		j=i-1
		while(key<a[j] and j>=0):
			a[j+1]=a[j]
			j=j-1
		a[j+1]=key
	print "a in function " , a


a=[1,8,44,66,2,45,23,77]
ins_sort(a)
print a
