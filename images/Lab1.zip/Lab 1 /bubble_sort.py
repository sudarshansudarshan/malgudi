def bubble_sort(a):
	""" Perform Bubble sort algorithm on the given list a. """
	l=len(a)
	for i in range(l):
		for j in range(l-i-1):
			if(a[j]>a[j+1]):
				a[j],a[j+1]=a[j+1],a[j]
	print "a in function " , a


a=[1,8,44,66,2,45,23,77]
bubble_sort(a)
print a
