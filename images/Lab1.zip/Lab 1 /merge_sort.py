def Merge_Sort(a):
	"""Perform merge sort algorithm on the given list a """
    #print("Splitting ",mylist)
	if len(a)>1:
		mid = len(a)//2
		left = a[:mid]
		right = a[mid:]
		Merge_Sort(left)
		Merge_Sort(right)
		i=0
		j=0
		k=0
		while i<len(left) and j<len(right):
			if left[i]<right[j]:
				a[k]=left[i]
				i=i+1
			else:
				a[k]=right[j]
				j=j+1
			k=k+1
		while i<len(left):
			a[k]=left[i]
			i=i+1
			k=k+1
		while j<len(right):
			a[k]=right[j]
			j=j+1
			k=k+1

a=[45,234,45,34,567,2,67,34,57,32,57]
Merge_Sort(a)
print(a)
